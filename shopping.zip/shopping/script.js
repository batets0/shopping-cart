const products = [
    {
      name: "Casual Suit",
      price: 45,
      quantity: 0,
      productId: 1,
      image: "images/pexels-eric-deine-342708-12749921.jpg",
    },
    {
      name: "Office Suit",
      price: 100,
      quantity: 0,
      productId: 2,
      image: "images/pexels-moh-adbelghaffar-17739667.jpg",
    },
    {
      name: "Shoes",
      price: 25,
      quantity: 0,
      productId: 3,
      image: "images/pexels-lilartsy-1159670.jpg",
    },
  ];
  
  let basket = JSON.parse(localStorage.getItem("data")) || [];
  
  const generateShop = () => {
    const shop = document.getElementById("shop");
    shop.innerHTML = products
      .map((product) => {
        return `
          <div id="product-id-${product.productId}" class="item">
            <img width="220" src=${product.image} alt="${product.name}">
            <div class="details">
              <h3>${product.name}</h3>
              <p>${product.price}</p>
              <div class="buttons">
                <button onclick="addProductToCart(${product.productId})">Add to Cart</button>
                <button onclick="increaseQuantity(${product.productId})">+</button>
                <button onclick="decreaseQuantity(${product.productId})">-</button>
                <button onclick="removeProductFromCart(${product.productId})">Remove</button>
              </div>
            </div>
          </div>
        `;
      })
      .join("");
  };
  
  generateShop();
  
  function addProductToCart(productId) {
    const product = products.find((p) => p.productId === productId);
    if (!product) return;
  
    const basketItem = basket.find((item) => item.productId === productId);
    if (basketItem) {
      basketItem.quantity += 1;
    } else {
      basket.push({ ...product, quantity: 1 });
    }
  
    localStorage.setItem("data", JSON.stringify(basket));
    generateCartItems();
  }
  
  function increaseQuantity(productId) {
    const basketItem = basket.find((item) => item.productId === productId);
    if (basketItem) {
      basketItem.quantity += 1;
      localStorage.setItem("data", JSON.stringify(basket));
      generateCartItems();
    }
  }
  
  function decreaseQuantity(productId) {
    const basketItem = basket.find((item) => item.productId === productId);
    if (basketItem) {
      basketItem.quantity -= 1;
      if (basketItem.quantity <= 0) {
        removeProductFromCart(productId);
      } else {
        localStorage.setItem("data", JSON.stringify(basket));
        generateCartItems();
      }
    }
  }
  
  function removeProductFromCart(productId) {
    basket = basket.filter((item) => item.productId !== productId);
    localStorage.setItem("data", JSON.stringify(basket));
    generateCartItems();
  }
  
  function cartTotal() {
    return basket.reduce((total, item) => total + item.price * item.quantity, 0);
  }
  
  let remainingBalance = 0;
  
  function pay(amount) {
    const total = cartTotal();
    remainingBalance = amount - total;
    return remainingBalance;
  }
  
  function handlePayment() {
    const amountPaid = parseFloat(document.getElementById("amountInput").value);
    if (isNaN(amountPaid) || amountPaid < 0) {
      document.getElementById("paymentResult").innerText = "Please enter a valid positive amount.";
      return;
    }
    const balance = pay(amountPaid);
    document.getElementById("paymentResult").innerText = `Remaining Balance: $${balance}`;
  }
  
  function generateCartItems() {
    const ShoppingCart = document.getElementById("shopping-cart");
    const label = document.getElementById("label");
  
    if (basket.length !== 0) {
      ShoppingCart.innerHTML = basket
        .map((item) => {
          return `
            <div class="cart-item">
              <img width="100" src=${item.image} alt="${item.name}">
              <div class="details">
                <h4>${item.name}</h4>
                <p>$${item.price}</p>
                <p>Quantity: ${item.quantity}</p>
                <p>Total: $${item.price * item.quantity}</p>
                <button onclick="increaseQuantity(${item.productId})">+</button>
                <button onclick="decreaseQuantity(${item.productId})">-</button>
                <button onclick="removeProductFromCart(${item.productId})">Remove</button>
              </div>
            </div>
          `;
        })
        .join("");
  
      const total = cartTotal();
      label.innerHTML = `<h2>Total Bill: $${total}</h2>`;
    } else {
      ShoppingCart.innerHTML = "<h2>Cart is Empty</h2>";
      label.innerHTML = "";
    }
  }
  
  generateCartItems();
  